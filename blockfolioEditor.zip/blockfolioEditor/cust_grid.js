var GridColumn = function(colwidth)
{
    this.width = colwidth;
    this.cssclass = "col-"+this.width;
    this.content = "<p>I AM COL CONTENT</p>";

    this.chgContent = function(type, content)
    {
        this.content = '<'+type+'>'+content+'</'+type+'>';
    }
};

var GridRow = function(cols)
{
    this.cssclass = "row";
    this.cols = cols;
    this.lista = [];
    this.appendMe = function()
    {
        var x = "<div data-pf_elemtype='gridRow' class='row'>";
        for(i = 0; i < this.cols; i++)
        {

            x += "<div data-pf_elemtype='gridColumn' class='"+this.lista[i].cssclass+"'>"+this.lista[i].content + "</div>";
        }
        x += "</div>";
        return x;
        console.log(x);
    }

    this.init = function()
    {
        for(bar = 0; bar < this.cols; bar++)
        {
            this.lista[bar] = new GridColumn(12/this.cols);
        }
    }

    this.tellCols = function()
    {
        for(bar = 0; bar < this.lista.length; bar++)
        {
            console.log(this.lista[bar]);
        }
    }

    this.resizeCol = function(x)
    {
        this.lista[x+1].width =- 1;


        this.lista[x].width++;
    }
}

var Grid = function()
{
    
}

